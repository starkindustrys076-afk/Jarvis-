package com.jarvis.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

// ---- Easy tweaks ----------------------------------------------------------
const val USER_NAME = "BOSS"          // shown in the greeting: GOOD EVENING, BOSS
val Cyan = Color(0xFF3DDCFF)
val Red = Color(0xFFFF3B4A)
val Mono = FontFamily.Monospace

// Apps preferred for the radial wheel (first 8 found are used, rest filled from your apps)
val PREFERRED = listOf(
    "com.google.android.dialer", "com.samsung.android.dialer", "com.android.dialer",
    "com.google.android.apps.messaging", "com.samsung.android.messaging",
    "com.android.camera", "com.sec.android.app.camera",
    "com.android.chrome", "com.google.android.apps.photos",
    "com.whatsapp", "com.instagram.android", "com.android.settings"
)
// ---------------------------------------------------------------------------

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap)

class MainActivity : ComponentActivity() {
    private var homeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { LauncherRoot(homeTick) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeTick++   // Home button pressed again -> close drawer, refresh apps
    }
}

fun launchApp(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
}

suspend fun loadApps(ctx: Context): List<AppInfo> = withContext(Dispatchers.Default) {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            AppInfo(
                label = it.loadLabel(pm).toString(),
                pkg = it.activityInfo.packageName,
                icon = it.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
            )
        }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun pickWheelApps(apps: List<AppInfo>): List<AppInfo> {
    val picked = PREFERRED.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }.take(8)
    return (picked + apps.filter { it !in picked }).take(8)
}

@Composable
fun rememberBattery(): State<Int> {
    val ctx = LocalContext.current
    val level = remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                level.intValue = if (s > 0) l * 100 / s else 0
            }
        }
        val sticky = ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sticky?.let { receiver.onReceive(ctx, it) }
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    return level
}

@Composable
fun LauncherRoot(homeTick: Int) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var drawer by remember { mutableStateOf(false) }

    LaunchedEffect(homeTick) {
        drawer = false
        apps = loadApps(ctx)
    }
    BackHandler(enabled = drawer) { drawer = false }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HomeScreen(apps) { drawer = true }
        AnimatedVisibility(
            visible = drawer,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            Drawer(apps) { drawer = false }
        }
    }
}

@Composable
fun HomeScreen(apps: List<AppInfo>, onOpenDrawer: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val battery by rememberBattery()
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000)
        }
    }

    val spin by rememberInfiniteTransition(label = "spin").animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(24000, easing = LinearEasing)),
        label = "spinValue"
    )
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.4f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "pulseValue"
    )

    val wheel = remember(apps) { pickWheelApps(apps) }
    val greeting = when (now.hour) {
        in 5..11 -> "MORNING"
        in 12..16 -> "AFTERNOON"
        in 17..20 -> "EVENING"
        else -> "NIGHT"
    }
    val timeText = now.format(DateTimeFormatter.ofPattern("HH:mm"))
    val dateText = now.format(DateTimeFormatter.ofPattern("EEE dd MMM", Locale.ENGLISH)).uppercase()

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -120f) onOpenDrawer() },
                    onVerticalDrag = { _, dy -> total += dy }
                )
            }
            .systemBarsPadding()
    ) {
        val wPx = with(density) { maxWidth.toPx() }
        val hPx = with(density) { maxHeight.toPx() }
        val cx = wPx / 2f
        val cy = hPx * 0.38f
        val r = wPx * 0.36f
        val c = Offset(cx, cy)

        // ---- Animated HUD rings ----
        Canvas(Modifier.fillMaxSize()) {
            // outer dashed ring
            rotate(spin, c) {
                drawCircle(
                    color = Cyan.copy(alpha = 0.35f), radius = r * 1.12f, center = c,
                    style = Stroke(1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 14f)))
                )
            }
            // segmented cyan ring
            rotate(-spin, c) {
                for (k in 0 until 6) {
                    drawArc(
                        color = Cyan.copy(alpha = 0.85f),
                        startAngle = k * 60f + 4f, sweepAngle = 44f, useCenter = false,
                        topLeft = c - Offset(r * 0.97f, r * 0.97f), size = Size(r * 1.94f, r * 1.94f),
                        style = Stroke(3f)
                    )
                }
            }
            // tick marks
            for (i in 0 until 72) {
                val a = Math.toRadians(i * 5.0)
                val len = if (i % 6 == 0) 14f else 6f
                val rr = r * 0.86f
                drawLine(
                    color = Cyan.copy(alpha = 0.4f),
                    start = c + Offset((cos(a) * rr).toFloat(), (sin(a) * rr).toFloat()),
                    end = c + Offset((cos(a) * (rr - len)).toFloat(), (sin(a) * (rr - len)).toFloat()),
                    strokeWidth = 1.5f
                )
            }
            // red inner arcs
            rotate(spin * 1.5f, c) {
                drawArc(
                    color = Red, startAngle = 0f, sweepAngle = 100f, useCenter = false,
                    topLeft = c - Offset(r * 0.36f, r * 0.36f), size = Size(r * 0.72f, r * 0.72f),
                    style = Stroke(3f)
                )
                drawArc(
                    color = Red.copy(alpha = 0.7f), startAngle = 180f, sweepAngle = 60f, useCenter = false,
                    topLeft = c - Offset(r * 0.36f, r * 0.36f), size = Size(r * 0.72f, r * 0.72f),
                    style = Stroke(3f)
                )
            }
            // core glow + ring
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Cyan.copy(alpha = 0.35f * pulse), Color.Transparent),
                    center = c, radius = r * 0.3f
                ),
                radius = r * 0.3f, center = c
            )
            drawCircle(Color.White.copy(alpha = 0.9f), radius = r * 0.17f, center = c, style = Stroke(3f))
            drawCircle(Cyan, radius = r * 0.21f, center = c, style = Stroke(2f))
        }

        // ---- Center button -> app drawer ----
        val coreHalf = with(density) { 30.dp.toPx() }
        Box(
            Modifier
                .offset { IntOffset((cx - coreHalf).roundToInt(), (cy - coreHalf).roundToInt()) }
                .size(60.dp)
                .clip(CircleShape)
                .clickable { onOpenDrawer() },
            contentAlignment = Alignment.Center
        ) {
            Text("APPS", color = Color.White, fontFamily = Mono, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }

        // ---- Radial app wheel ----
        val half = with(density) { 19.dp.toPx() }
        wheel.forEachIndexed { i, app ->
            val a = Math.toRadians(-90.0 + i * 360.0 / wheel.size)
            val bx = cx + r * 0.6f * cos(a).toFloat()
            val by = cy + r * 0.6f * sin(a).toFloat()
            Box(
                Modifier
                    .offset { IntOffset((bx - half).roundToInt(), (by - half).roundToInt()) }
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xCC001018))
                    .border(1.dp, Cyan.copy(alpha = 0.7f), CircleShape)
                    .clickable { launchApp(ctx, app.pkg) },
                contentAlignment = Alignment.Center
            ) {
                Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(26.dp))
            }
        }

        // ---- Top HUD ----
        Column(Modifier.align(Alignment.TopStart).padding(16.dp)) {
            Text(timeText, color = Cyan, fontFamily = Mono, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text(dateText, color = Cyan.copy(alpha = 0.7f), fontFamily = Mono, fontSize = 12.sp)
        }
        Column(Modifier.align(Alignment.TopEnd).padding(16.dp), horizontalAlignment = Alignment.End) {
            Text(
                "PWR $battery%",
                color = if (battery < 20) Red else Cyan,
                fontFamily = Mono, fontSize = 14.sp, fontWeight = FontWeight.Bold
            )
            Text("SYS ONLINE", color = Red.copy(alpha = pulse), fontFamily = Mono, fontSize = 10.sp)
        }

        // ---- Greeting + status lines ----
        val greetY = (cy + r * 1.25f).roundToInt()
        Column(
            Modifier
                .offset { IntOffset(0, greetY) }
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            Text(
                "GOOD $greeting, $USER_NAME",
                color = Color.White, fontFamily = Mono, fontSize = 16.sp, fontWeight = FontWeight.Bold
            )
            Text(
                "ALL SYSTEMS NOMINAL  //  POWER $battery%",
                color = Cyan.copy(alpha = 0.8f), fontFamily = Mono, fontSize = 10.sp
            )
            Canvas(Modifier.fillMaxWidth().height(28.dp).padding(top = 10.dp)) {
                drawLine(Red, Offset(0f, size.height * 0.7f), Offset(size.width, size.height * 0.2f), 2f)
                drawLine(Cyan.copy(alpha = 0.8f), Offset(0f, size.height * 0.9f), Offset(size.width, size.height * 0.5f), 2f)
                for (i in 0..20) {
                    val x = size.width * i / 20f
                    drawLine(Cyan.copy(alpha = 0.4f), Offset(x, size.height), Offset(x, size.height - 6f), 1.5f)
                }
            }
        }

        // ---- Bottom hint ----
        Text(
            "▲  SWIPE UP  //  ALL APPS",
            color = Cyan.copy(alpha = 0.8f * pulse),
            fontFamily = Mono, fontSize = 11.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp)
        )
    }
}

@Composable
fun Drawer(apps: List<AppInfo>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val shown = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xF2000000))
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 12.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .border(1.dp, Cyan.copy(alpha = 0.6f))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = TextStyle(color = Cyan, fontFamily = Mono, fontSize = 16.sp),
                cursorBrush = SolidColor(Cyan),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    if (query.isEmpty()) {
                        Text("SEARCH APPS...", color = Cyan.copy(alpha = 0.4f), fontFamily = Mono, fontSize = 14.sp)
                    }
                    inner()
                }
            )
            Text(
                "X", color = Red, fontFamily = Mono, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onClose() }.padding(start = 16.dp)
            )
        }

        LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.fillMaxSize()) {
            items(shown, key = { it.pkg }) { app ->
                Column(
                    Modifier.clickable { launchApp(ctx, app.pkg) }.padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(48.dp))
                    Text(
                        app.label, color = Cyan, fontFamily = Mono, fontSize = 10.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}
